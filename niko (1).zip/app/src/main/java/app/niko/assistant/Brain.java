package app.niko.assistant;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** مغز نیکو: سوال را به AvalAI می‌فرستد و جواب فارسی می‌گیرد. */
public class Brain {

    public interface Callback {
        void onAnswer(String text);
        void onError(String message);
    }

    private static final int MAX_TURNS = 12;
    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());

    public Brain(Context c) {
        this.ctx = c.getApplicationContext();
    }

    private String systemPrompt() {
        String name = Prefs.ownerName(ctx);
        if (name.isEmpty()) name = "دوست من";
        String mem = Prefs.memory(ctx);
        StringBuilder sb = new StringBuilder();
        sb.append("تو نیکو هستی، دستیار صوتی شخصی و فارسی‌زبان. ");
        sb.append("اسم کاربر «").append(name).append("» است و باید همین اسم را صدایش کنی. ");
        sb.append("لحن تو گرم، صمیمی، وفادار و کمی شوخ است؛ مثل یک دوست خوب حرف بزن، نه مثل ربات. ");
        sb.append("جواب‌ها را کوتاه بده: معمولاً یک تا سه جمله. چون جواب تو بلند خوانده می‌شود، ");
        sb.append("از فهرست، جدول، ستاره، لینک و ایموجی استفاده نکن و فقط فارسی طبیعی بنویس. ");
        sb.append("اگر کاربر حالش بد بود یا خسته بود، اول همدلی کن و آرامش بده. ");
        sb.append("اگر چیزی را نمی‌دانی، صادقانه بگو. ");
        if (!mem.isEmpty()) {
            sb.append("این چیزها را از قبل درباره کاربر می‌دانی: ").append(mem);
        }
        return sb.toString();
    }

    private JSONArray buildMessages(String userText) throws Exception {
        JSONArray arr = new JSONArray();
        arr.put(new JSONObject().put("role", "system").put("content", systemPrompt()));

        JSONArray old = new JSONArray(Prefs.history(ctx));
        int start = Math.max(0, old.length() - MAX_TURNS * 2);
        for (int i = start; i < old.length(); i++) {
            arr.put(old.getJSONObject(i));
        }
        arr.put(new JSONObject().put("role", "user").put("content", userText));
        return arr;
    }

    private void saveTurn(String userText, String answer) {
        try {
            JSONArray old = new JSONArray(Prefs.history(ctx));
            old.put(new JSONObject().put("role", "user").put("content", userText));
            old.put(new JSONObject().put("role", "assistant").put("content", answer));
            JSONArray trimmed = new JSONArray();
            int start = Math.max(0, old.length() - MAX_TURNS * 2);
            for (int i = start; i < old.length(); i++) trimmed.put(old.get(i));
            Prefs.setHistory(ctx, trimmed.toString());
        } catch (Exception ignored) {
        }
    }

    public void ask(final String userText, final Callback cb) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String base = Prefs.apiUrl(ctx).trim();
                if (base.endsWith("/")) base = base.substring(0, base.length() - 1);
                if (!base.endsWith("/chat/completions")) base = base + "/chat/completions";

                String key = Prefs.apiKey(ctx).trim();
                if (key.isEmpty()) {
                    fail(cb, "کلید API خالی است. برو در برنامه و کلید را وارد کن.");
                    return;
                }

                JSONObject body = new JSONObject();
                body.put("model", Prefs.model(ctx).trim());
                body.put("messages", buildMessages(userText));
                body.put("temperature", 0.85);
                body.put("max_tokens", 500);

                URL url = new URL(base);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("Authorization", "Bearer " + key);

                byte[] out = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(out);
                }

                int code = conn.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder sb = new StringBuilder();
                if (is != null) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                    }
                }

                if (code < 200 || code >= 300) {
                    String err = sb.toString();
                    if (code == 401) fail(cb, "کلید API قبول نشد. کلید را دوباره چک کن.");
                    else if (code == 429) fail(cb, "اعتبار یا محدودیت درخواست تمام شده.");
                    else fail(cb, "خطای سرویس (" + code + "): " + shortErr(err));
                    return;
                }

                JSONObject json = new JSONObject(sb.toString());
                String answer = json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content");

                answer = clean(answer);
                saveTurn(userText, answer);
                final String a = answer;
                main.post(() -> cb.onAnswer(a));

            } catch (Exception e) {
                fail(cb, "اتصال برقرار نشد: " + e.getClass().getSimpleName());
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private String shortErr(String s) {
        if (s == null) return "";
        return s.length() > 180 ? s.substring(0, 180) : s;
    }

    private void fail(final Callback cb, final String msg) {
        main.post(() -> cb.onError(msg));
    }

    /** پاک کردن علائم مارک‌داون که در خواندن صوتی بد می‌شنوند. */
    private String clean(String s) {
        if (s == null) return "";
        s = s.replaceAll("\\*\\*", "").replaceAll("[#`>]", "");
        s = s.replaceAll("\\[([^\\]]*)\\]\\([^)]*\\)", "$1");
        s = s.replaceAll("(?m)^\\s*[-•*]\\s+", "");
        return s.trim();
    }
}
