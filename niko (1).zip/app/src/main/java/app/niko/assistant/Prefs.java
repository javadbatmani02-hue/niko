package app.niko.assistant;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {

    private static final String FILE = "niko_prefs";

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static String ownerName(Context c) {
        return get(c).getString("owner_name", "");
    }

    public static void setOwnerName(Context c, String n) {
        get(c).edit().putString("owner_name", n).apply();
    }

    public static String wakeWord(Context c) {
        String w = get(c).getString("wake_word", "نیکو");
        return (w == null || w.trim().isEmpty()) ? "نیکو" : w;
    }

    public static void setWakeWord(Context c, String w) {
        get(c).edit().putString("wake_word", w).apply();
    }

    public static String apiUrl(Context c) {
        return get(c).getString("api_url", "https://api.avalai.ir/v1");
    }

    public static String apiKey(Context c) {
        return get(c).getString("api_key", "");
    }

    public static String model(Context c) {
        return get(c).getString("model", "gpt-4o-mini");
    }

    public static String voiceModel(Context c) {
        return get(c).getString("voice_model", "gpt-audio-mini");
    }

    public static void setApi(Context c, String url, String key, String model) {
        get(c).edit().putString("api_url", url)
                .putString("api_key", key)
                .putString("model", model)
                .apply();
    }

    public static String memory(Context c) {
        return get(c).getString("memory", "");
    }

    public static void setMemory(Context c, String m) {
        get(c).edit().putString("memory", m).apply();
    }

    public static void addMemory(Context c, String line) {
        String old = memory(c);
        String neu = old.isEmpty() ? line : old + "\n" + line;
        if (neu.length() > 4000) neu = neu.substring(neu.length() - 4000);
        setMemory(c, neu);
    }

    public static void clearMemory(Context c) {
        get(c).edit().putString("memory", "").apply();
    }

    public static String history(Context c) {
        return get(c).getString("history", "[]");
    }

    public static void setHistory(Context c, String json) {
        get(c).edit().putString("history", json).apply();
    }

    public static void clearHistory(Context c) {
        get(c).edit().putString("history", "[]").apply();
    }

    public static boolean wantRunning(Context c) {
        return get(c).getBoolean("want_running", false);
    }

    public static void setWantRunning(Context c, boolean v) {
        get(c).edit().putBoolean("want_running", v).apply();
    }
}
