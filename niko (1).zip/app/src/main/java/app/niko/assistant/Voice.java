package app.niko.assistant;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * گوش و زبان نیکو.
 * گوش: فایل صوتی را به AvalAI می‌فرستد و متن فارسی می‌گیرد.
 * زبان: متن فارسی را به AvalAI می‌دهد و صدا می‌گیرد و پخش می‌کند.
 * به موتور گفتار گوشی کاری ندارد؛ پس روی هواوی هم فارسی حرف می‌زند.
 */
public class Voice {

    public interface SttCb {
        void onText(String text);
        void onError(String msg);
    }

    public interface TtsCb {
        void onDone();
        void onError(String msg);
    }

    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaPlayer player;

    public Voice(Context c) {
        this.ctx = c.getApplicationContext();
    }

    private String base() {
        String b = Prefs.apiUrl(ctx).trim();
        if (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        if (b.endsWith("/chat/completions")) b = b.substring(0, b.length() - "/chat/completions".length());
        return b;
    }

    // ---------------- گوش ----------------

    public void transcribe(final File wav, final SttCb cb) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String boundary = "----Niko" + System.currentTimeMillis();
                URL url = new URL(base() + "/audio/transcriptions");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.setRequestProperty("Authorization", "Bearer " + Prefs.apiKey(ctx).trim());
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

                DataOutputStream out = new DataOutputStream(conn.getOutputStream());

                writeField(out, boundary, "model", "gpt-transcribe");
                writeField(out, boundary, "language", "fa");

                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"niko.wav\"\r\n");
                out.writeBytes("Content-Type: audio/wav\r\n\r\n");
                byte[] data = readAll(wav);
                out.write(data);
                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
                out.close();

                int code = conn.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                String body = readText(is);

                if (code < 200 || code >= 300) {
                    failStt(cb, "گوش خطا داد (" + code + ")");
                    return;
                }

                String text = new JSONObject(body).optString("text", "").trim();
                if (text.isEmpty()) {
                    failStt(cb, "چیزی نشنیدم");
                    return;
                }
                main.post(() -> cb.onText(text));

            } catch (Exception e) {
                failStt(cb, "گوش وصل نشد");
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void writeField(DataOutputStream out, String boundary, String name, String value) throws Exception {
        out.writeBytes("--" + boundary + "\r\n");
        out.writeBytes("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n");
        out.write(value.getBytes(StandardCharsets.UTF_8));
        out.writeBytes("\r\n");
    }

    private void failStt(final SttCb cb, final String m) {
        main.post(() -> cb.onError(m));
    }

    // ---------------- زبان ----------------

    public void speak(final String text, final TtsCb cb) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject body = new JSONObject();
                body.put("model", Prefs.voiceModel(ctx));
                body.put("input", text);
                body.put("voice", "alloy");
                body.put("response_format", "mp3");

                URL url = new URL(base() + "/audio/speech");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + Prefs.apiKey(ctx).trim());

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) {
                    String e = readText(conn.getErrorStream());
                    failTts(cb, "زبان خطا داد (" + code + ") " + e);
                    return;
                }

                File f = new File(ctx.getCacheDir(), "niko_reply.mp3");
                try (InputStream in = conn.getInputStream();
                     FileOutputStream fos = new FileOutputStream(f)) {
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) fos.write(b, 0, n);
                }

                main.post(() -> play(f, cb));

            } catch (Exception e) {
                failTts(cb, "زبان وصل نشد");
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void play(File f, final TtsCb cb) {
        try {
            stopSpeaking();
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                cb.onDone();
                releasePlayer();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                cb.onError("پخش صدا نشد");
                releasePlayer();
                return true;
            });
            player.prepare();
            player.start();
        } catch (Exception e) {
            cb.onError("پخش صدا نشد");
            releasePlayer();
        }
    }

    private void failTts(final TtsCb cb, final String m) {
        main.post(() -> cb.onError(m));
    }

    public void stopSpeaking() {
        try {
            if (player != null && player.isPlaying()) player.stop();
        } catch (Exception ignored) {
        }
        releasePlayer();
    }

    private void releasePlayer() {
        try {
            if (player != null) player.release();
        } catch (Exception ignored) {
        }
        player = null;
    }

    public boolean isSpeaking() {
        try {
            return player != null && player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------- کمکی ----------------

    private byte[] readAll(File f) throws Exception {
        try (InputStream in = new java.io.FileInputStream(f)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bos.write(b, 0, n);
            return bos.toByteArray();
        }
    }

    private String readText(InputStream is) {
        if (is == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = br.readLine()) != null) sb.append(l);
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
