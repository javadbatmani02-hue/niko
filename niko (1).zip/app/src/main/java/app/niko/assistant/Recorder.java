package app.niko.assistant;

import android.annotation.SuppressLint;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

/**
 * ضبط صدا با تشخیص خودکار شروع و پایان حرف زدن.
 * به‌جای موتور گفتار گوگل (که روی هواوی نیست) خودمان صدا را می‌گیریم.
 */
public class Recorder {

    public static final int RATE = 16000;

    public interface Listener {
        /** یک تکه گفتار کامل شد؛ فایل wav آماده است. */
        void onSpeech(File wav);
        /** هیچ حرفی زده نشد. */
        void onSilence();
    }

    private volatile boolean running = false;
    private AudioRecord record;
    private Thread thread;

    @SuppressLint("MissingPermission")
    public void start(final Listener listener) {
        if (running) return;
        running = true;

        thread = new Thread(() -> {
            int minBuf = AudioRecord.getMinBufferSize(RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bufSize = Math.max(minBuf, RATE); // ~1 ثانیه

            try {
                record = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        RATE, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, bufSize * 2);
            } catch (Exception e) {
                running = false;
                return;
            }

            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                running = false;
                safeRelease();
                return;
            }

            short[] buf = new short[bufSize];
            ByteArrayOutputStream speech = new ByteArrayOutputStream();
            boolean talking = false;
            int silenceMs = 0;
            int speechMs = 0;

            // آستانه‌ی صدا: با نویز محیط خودش را تنظیم می‌کند
            double noise = 300;

            try {
                record.startRecording();
            } catch (Exception e) {
                running = false;
                safeRelease();
                return;
            }

            while (running) {
                int n = record.read(buf, 0, buf.length);
                if (n <= 0) continue;

                double sum = 0;
                for (int i = 0; i < n; i++) sum += (double) buf[i] * buf[i];
                double rms = Math.sqrt(sum / n);
                int ms = (int) (n * 1000L / RATE);

                boolean loud = rms > Math.max(noise * 2.2, 550);

                if (!talking) {
                    // پیگیری نویز پایه
                    noise = noise * 0.97 + rms * 0.03;
                    if (loud) {
                        talking = true;
                        silenceMs = 0;
                        speechMs = 0;
                        speech.reset();
                        writeShorts(speech, buf, n);
                        speechMs += ms;
                    }
                } else {
                    writeShorts(speech, buf, n);
                    speechMs += ms;
                    if (loud) silenceMs = 0;
                    else silenceMs += ms;

                    boolean finished = silenceMs > 900 || speechMs > 12000;
                    if (finished) {
                        talking = false;
                        if (speechMs > 400) {
                            File f = save(speech.toByteArray());
                            if (f != null && listener != null) listener.onSpeech(f);
                        }
                    }
                }
            }

            safeRelease();
        }, "niko-rec");
        thread.start();
    }

    public void stop() {
        running = false;
        try {
            if (thread != null) thread.join(1500);
        } catch (InterruptedException ignored) {
        }
        safeRelease();
    }

    public boolean isRunning() {
        return running;
    }

    private void safeRelease() {
        try {
            if (record != null) {
                if (record.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) record.stop();
                record.release();
            }
        } catch (Exception ignored) {
        }
        record = null;
    }

    private void writeShorts(ByteArrayOutputStream out, short[] buf, int n) {
        for (int i = 0; i < n; i++) {
            out.write(buf[i] & 0xff);
            out.write((buf[i] >> 8) & 0xff);
        }
    }

    /** ساختن فایل wav با هدر استاندارد. */
    private File save(byte[] pcm) {
        try {
            File f = new File(App.get().getCacheDir(), "niko.wav");
            FileOutputStream fos = new FileOutputStream(f);
            int dataLen = pcm.length;
            int fileLen = dataLen + 36;
            byte[] h = new byte[44];

            h[0] = 'R'; h[1] = 'I'; h[2] = 'F'; h[3] = 'F';
            h[4] = (byte) (fileLen & 0xff);
            h[5] = (byte) ((fileLen >> 8) & 0xff);
            h[6] = (byte) ((fileLen >> 16) & 0xff);
            h[7] = (byte) ((fileLen >> 24) & 0xff);
            h[8] = 'W'; h[9] = 'A'; h[10] = 'V'; h[11] = 'E';
            h[12] = 'f'; h[13] = 'm'; h[14] = 't'; h[15] = ' ';
            h[16] = 16; h[17] = 0; h[18] = 0; h[19] = 0;
            h[20] = 1; h[21] = 0;
            h[22] = 1; h[23] = 0;
            h[24] = (byte) (RATE & 0xff);
            h[25] = (byte) ((RATE >> 8) & 0xff);
            h[26] = (byte) ((RATE >> 16) & 0xff);
            h[27] = (byte) ((RATE >> 24) & 0xff);
            int byteRate = RATE * 2;
            h[28] = (byte) (byteRate & 0xff);
            h[29] = (byte) ((byteRate >> 8) & 0xff);
            h[30] = (byte) ((byteRate >> 16) & 0xff);
            h[31] = (byte) ((byteRate >> 24) & 0xff);
            h[32] = 2; h[33] = 0;
            h[34] = 16; h[35] = 0;
            h[36] = 'd'; h[37] = 'a'; h[38] = 't'; h[39] = 'a';
            h[40] = (byte) (dataLen & 0xff);
            h[41] = (byte) ((dataLen >> 8) & 0xff);
            h[42] = (byte) ((dataLen >> 16) & 0xff);
            h[43] = (byte) ((dataLen >> 24) & 0xff);

            fos.write(h);
            fos.write(pcm);
            fos.close();
            return f;
        } catch (Exception e) {
            return null;
        }
    }
}
