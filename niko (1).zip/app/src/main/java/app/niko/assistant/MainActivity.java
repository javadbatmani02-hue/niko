package app.niko.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** صفحه‌ی تنظیمات نیکو. */
public class MainActivity extends Activity {

    private static final int REQ_MIC = 10;
    private static final int REQ_NOTIF = 11;

    private EditText etName, etWake, etUrl, etKey, etModel, etVoice;
    private TextView tvStatus, tvModel;
    private Button btnDownload, btnStart, btnStop, btnClear;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etWake = findViewById(R.id.etWake);
        etUrl = findViewById(R.id.etUrl);
        etKey = findViewById(R.id.etKey);
        etModel = findViewById(R.id.etModel);
        etVoice = findViewById(R.id.etVoice);
        tvStatus = findViewById(R.id.tvStatus);
        tvModel = findViewById(R.id.tvModel);
        btnDownload = findViewById(R.id.btnDownload);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnClear = findViewById(R.id.btnClear);

        load();

        btnDownload.setOnClickListener(v -> {
            save();
            downloadModel();
        });
        btnStart.setOnClickListener(v -> {
            save();
            if (!hasMic()) {
                askMic();
                return;
            }
            askNotification();
            askBattery();
            if (!WakeWord.modelReady(this)) {
                toast("اول مدل صوتی را دانلود کن");
                return;
            }
            startNiko();
        });
        btnStop.setOnClickListener(v -> stopNiko());
        btnClear.setOnClickListener(v -> {
            Prefs.clearHistory(this);
            Prefs.clearMemory(this);
            toast("حافظه پاک شد");
        });

        askNotification();
    }

    private void load() {
        etName.setText(Prefs.ownerName(this));
        etWake.setText(Prefs.wakeWord(this));
        etUrl.setText(Prefs.apiUrl(this));
        etKey.setText(Prefs.apiKey(this));
        etModel.setText(Prefs.model(this));
        etVoice.setText(Prefs.voiceModel(this));
        refreshModelState();
    }

    private void save() {
        Prefs.setOwnerName(this, text(etName));
        String w = text(etWake);
        Prefs.setWakeWord(this, w.isEmpty() ? "نیکو" : w);
        String u = text(etUrl);
        Prefs.setApi(this, u.isEmpty() ? "https://api.avalai.ir/v1" : u,
                text(etKey), text(etModel).isEmpty() ? "gpt-4o-mini" : text(etModel));
        if (!text(etVoice).isEmpty()) {
            Prefs.get(this).edit().putString("voice_model", text(etVoice)).apply();
        }
    }

    private String text(EditText e) {
        return e.getText().toString().trim();
    }

    // ---------------- مدل صوتی ----------------

    private void refreshModelState() {
        boolean ready = WakeWord.modelReady(this);
        tvModel.setText(ready ? "مدل صوتی: نصب است ✓" : "مدل صوتی: نصب نیست ✗");
        btnDownload.setEnabled(!ready);
        btnDownload.setText(ready ? "مدل نصب است" : "دانلود مدل صوتی (۵۰ مگ)");
    }

    private void downloadModel() {
        btnDownload.setEnabled(false);
        tvModel.setText("دانلود ۰٪");
        new ModelDownloader(this).download(new ModelDownloader.Cb() {
            @Override
            public void onProgress(int p) {
                tvModel.setText("دانلود " + p + "٪");
            }

            @Override
            public void onDone() {
                tvModel.setText("مدل صوتی: نصب است ✓");
                btnDownload.setText("مدل نصب است");
                toast("مدل آماده شد");
            }

            @Override
            public void onError(String msg) {
                tvModel.setText("مدل صوتی: نصب نیست ✗");
                btnDownload.setEnabled(true);
                toast(msg);
            }
        });
    }

    // ---------------- روشن/خاموش ----------------

    private void startNiko() {
        Prefs.setWantRunning(this, true);
        Intent i = new Intent(this, NikoService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
        toast("نیکو روشن شد — بگو «نیکو»");
        tvStatus.setText("وضعیت: روشن");
        btnStart.setEnabled(false);
        btnStop.setEnabled(true);
    }

    private void stopNiko() {
        Prefs.setWantRunning(this, false);
        stopService(new Intent(this, NikoService.class));
        toast("نیکو خاموش شد");
        tvStatus.setText("وضعیت: خاموش");
        btnStart.setEnabled(true);
        btnStop.setEnabled(false);
    }

    private boolean serviceAlive() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;
            List<ActivityManager.RunningServiceInfo> list = am.getRunningServices(200);
            String mine = getPackageName() + "/" + NikoService.class.getName();
            for (ActivityManager.RunningServiceInfo s : list) {
                if (mine.equals(s.service.flattenToString())
                        || NikoService.class.getName().equals(s.service.getClassName())) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    // ---------------- دسترسی‌ها ----------------

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void askMic() {
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
    }

    private void askNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_MIC && (r.length == 0 || r[0] != PackageManager.PERMISSION_GRANTED)) {
            toast("بدون میکروفون نمی‌توانم بشنوم");
        }
    }

    private void askBattery() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    i.setData(android.net.Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean want = Prefs.wantRunning(this);
        if (want && !serviceAlive() && hasMic() && WakeWord.modelReady(this)) {
            Intent i = new Intent(this, NikoService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
        }
        boolean alive = serviceAlive();
        tvStatus.setText(alive ? "وضعیت: روشن" : "وضعیت: خاموش");
        btnStart.setEnabled(!alive);
        btnStop.setEnabled(alive);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
