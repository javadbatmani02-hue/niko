package app.niko.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * مغز و گوشِ همیشه‌بیدارِ نیکو.
 * چرخه: گوش به بیدارباش -> شنیدن حرف -> تبدیل به متن -> فکر کردن -> جواب دادن.
 */
public class NikoService extends Service {

    private static final String TAG = "Niko";
    private static final String CHANNEL = "niko_channel";
    private static final int NOTIF_ID = 2201;
    private static final long FOLLOW_UP_MS = 9000;

    public static final String ACTION_STOP = "app.niko.assistant.STOP";

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WakeWord wake;
    private Recorder recorder;
    private Voice voice;
    private Brain brain;
    private PowerManager.WakeLock wakeLock;

    private volatile boolean busy = false;
    private volatile boolean awake = false;
    private boolean followUp = false;

    @Override
    public void onCreate() {
        super.onCreate();
        voice = new Voice(this);
        brain = new Brain(this);
        wake = new WakeWord(this);
        createChannel();
        acquireLock();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Prefs.setWantRunning(this, false);
            stopSelf();
            return START_NOT_STICKY;
        }

        Prefs.setWantRunning(this, true);
        startForeground(NOTIF_ID, buildNotification("در حال آماده شدن…"));

        if (!WakeWord.modelReady(this)) {
            notify("مدل صوتی نصب نیست — برنامه را باز کن");
            stopSelf();
            return START_NOT_STICKY;
        }

        handler.postDelayed(this::startWake, 400);
        return START_STICKY;
    }

    // ---------------- چرخه‌ی اصلی ----------------

    private void startWake() {
        if (busy) return;
        awake = false;
        followUp = false;
        notify("منتظر «نیکو» هستم");
        wake.start(this::onWake);
    }

    private void onWake() {
        if (busy) return;
        busy = true;
        awake = true;

        wake.stop();
        notify("گوش می‌دهم…");

        handler.postDelayed(() -> listenOnce(false), 250);
    }

    private void listenOnce(final boolean isFollowUp) {
        followUp = isFollowUp;

        recorder = new Recorder();
        recorder.start(new Recorder.Listener() {
            @Override
            public void onSpeech(File wav) {
                recorder.stop();
                recorder = null;
                think(wav);
            }

            @Override
            public void onSilence() {
                recorder.stop();
                recorder = null;
                busy = false;
                awake = false;
                notify("چیزی نشنیدم");
                handler.postDelayed(NikoService.this::startWake, 600);
            }
        });

        // اگر کسی حرف نزد، بعد از ۱۵ ثانیه برگرد به حالت بیدارباش
        handler.postDelayed(() -> {
            if (recorder != null) {
                recorder.stop();
                recorder = null;
                busy = false;
                awake = false;
                notify("منتظر «نیکو» هستم");
                startWake();
            }
        }, 15000);
    }

    private void think(File wav) {
        notify("دارم می‌فهمم…");

        voice.transcribe(wav, new Voice.SttCb() {
            @Override
            public void onText(String text) {
                handleText(text);
            }

            @Override
            public void onError(String msg) {
                Log.w(TAG, "stt: " + msg);
                busy = false;
                awake = false;
                notify(msg);
                handler.postDelayed(NikoService.this::startWake, 800);
            }
        });
    }

    private void handleText(String raw) {
        String text = normalize(raw);

        // در حالت ادامه‌ی گفتگو، کلمه‌ی بیدارباش لازم نیست
        if (!followUp) {
            String w = normalize(Prefs.wakeWord(NikoService.this));
            int idx = text.indexOf(w);
            if (idx < 0) {
                busy = false;
                awake = false;
                notify("منتظر «نیکو» هستم");
                startWake();
                return;
            }
            text = text.substring(idx + w.length()).trim();
        }

        if (text.isEmpty()) {
            busy = false;
            awake = false;
            notify("بله؟");
            handler.postDelayed(() -> listenOnce(true), 300);
            return;
        }

        String local = localCommand(text);
        if (local != null) {
            speak(local);
            return;
        }

        notify("دارم فکر می‌کنم…");
        brain.ask(text, new Brain.Callback() {
            @Override
            public void onAnswer(String answer) {
                speak(answer);
            }

            @Override
            public void onError(String message) {
                Log.w(TAG, "brain: " + message);
                speak(message);
            }
        });
    }

    private void speak(String text) {
        notify("دارم جواب می‌دم…");
        voice.speak(text, new Voice.TtsCb() {
            @Override
            public void onDone() {
                busy = false;
                awake = false;
                notify("منتظر «نیکو» هستم");
                // چند ثانیه فرصت ادامه‌ی گفتگو
                handler.postDelayed(() -> {
                    busy = true;
                    awake = true;
                    notify("باز هم بگو…");
                    listenOnce(true);
                }, 700);
            }

            @Override
            public void onError(String msg) {
                Log.w(TAG, "tts: " + msg);
                busy = false;
                awake = false;
                notify("صدا پخش نشد");
                handler.postDelayed(NikoService.this::startWake, 800);
            }
        });
    }

    // ---------------- دستورهای محلی (بدون اینترنت) ----------------

    private String localCommand(String t) {
        String s = t.replace("؟", "").replace("?", "").trim();

        if (s.contains("ساعت") && (s.contains("چند") || s.contains("چیه") || s.contains("بگو"))) {
            Calendar c = Calendar.getInstance();
            int h = c.get(Calendar.HOUR_OF_DAY);
            int m = c.get(Calendar.MINUTE);
            return "الان ساعت " + fa(h) + " و " + fa(m) + " دقیقه‌ست.";
        }

        if (s.contains("تاریخ") || s.contains("چندم")) {
            SimpleDateFormat f = new SimpleDateFormat("d MMMM yyyy", new Locale("fa", "IR"));
            return "امروز " + f.format(new Date()) + " است.";
        }

        if (s.contains("خداحافظ") || s.contains("بای") || s.contains("برو بخواب")) {
            handler.postDelayed(() -> {
                Prefs.setWantRunning(NikoService.this, false);
                stopSelf();
            }, 1500);
            return "باشه، هر وقت خواستی صدام کن. خداحافظ.";
        }

        if (s.contains("اسمت") || s.contains("کی هستی")) {
            return "من نیکو هستم، دستیار خودت.";
        }

        if (s.contains("حافظه") && (s.contains("پاک") || s.contains("فراموش"))) {
            Prefs.clearMemory(this);
            Prefs.clearHistory(this);
            return "حافظه‌ام را پاک کردم.";
        }

        return null;
    }

    private String fa(int n) {
        String[] d = {"صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه", "ده",
                "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده", "بیست"};
        if (n <= 20) return d[n];
        if (n < 30) return "بیست و " + d[n - 20];
        if (n < 60) {
            int t = n / 10;
            String[] tens = {"", "", "بیست", "سی", "چهل", "پنجاه"};
            int r = n % 10;
            return tens[t] + (r == 0 ? "" : " و " + d[r]);
        }
        return String.valueOf(n);
    }

    private String normalize(String s) {
        if (s == null) return "";
        return s.replace("ي", "ی").replace("ك", "ک")
                .replace("‌", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    // ---------------- نوتیفیکیشن ----------------

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "نیکو",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, flags);

        Intent stop = new Intent(this, NikoService.class).setAction(ACTION_STOP);
        PendingIntent ps = PendingIntent.getService(this, 1, stop, flags);

        Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);

        b.setContentTitle("نیکو")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "خاموش", ps).build());

        return b.build();
    }

    private void notify(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification(text));
        } catch (Exception ignored) {
        }
    }

    // ---------------- قفل بیداری ----------------

    private void acquireLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "niko:service");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception ignored) {
        }
    }

    private void releaseLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {
        }
        wakeLock = null;
    }

    // ---------------- پایان ----------------

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (recorder != null) recorder.stop();
        } catch (Exception ignored) {
        }
        recorder = null;
        try {
            if (wake != null) wake.release();
        } catch (Exception ignored) {
        }
        try {
            if (voice != null) {
                voice.stopSpeaking();
                voice = null;
            }
        } catch (Exception ignored) {
        }
        releaseLock();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
