package app.niko.assistant;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** دانلود و باز کردن مدل فارسی Vosk (حدود ۵۰ مگابایت، فقط یک بار). */
public class ModelDownloader {

    public static final String URL_FA =
            "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.5.zip";

    public interface Cb {
        void onProgress(int percent);
        void onDone();
        void onError(String msg);
    }

    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());

    public ModelDownloader(Context c) {
        this.ctx = c.getApplicationContext();
    }

    public void download(final Cb cb) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                File zip = new File(ctx.getCacheDir(), "vosk-fa.zip");
                URL url = new URL(URL_FA);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(120000);
                conn.connect();

                int total = conn.getContentLength();
                try (InputStream in = conn.getInputStream();
                     FileOutputStream fos = new FileOutputStream(zip)) {
                    byte[] b = new byte[16384];
                    int n, done = 0, last = -1;
                    while ((n = in.read(b)) > 0) {
                        fos.write(b, 0, n);
                        done += n;
                        if (total > 0) {
                            int p = done * 100 / total;
                            if (p != last) {
                                last = p;
                                final int pp = p;
                                main.post(() -> cb.onProgress(pp));
                            }
                        }
                    }
                }

                unzip(zip, WakeWord.modelDir(ctx));
                zip.delete();

                if (!WakeWord.modelReady(ctx)) {
                    main.post(() -> cb.onError("فایل مدل خراب بود"));
                    return;
                }
                main.post(cb::onDone);

            } catch (Exception e) {
                main.post(() -> cb.onError("دانلود نشد: " + e.getClass().getSimpleName()));
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void unzip(File zip, File dest) throws Exception {
        File tmp = new File(dest.getParentFile(), "vosk-tmp");
        deleteTree(tmp);
        if (!tmp.mkdirs()) throw new Exception("mkdir");

        try (ZipInputStream zis = new ZipInputStream(new java.io.FileInputStream(zip))) {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zis.getNextEntry()) != null) {
                File out = new File(tmp, e.getName());
                if (e.isDirectory()) {
                    out.mkdirs();
                } else {
                    File parent = out.getParentFile();
                    if (parent != null) parent.mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(out)) {
                        int n;
                        while ((n = zis.read(buf)) > 0) fos.write(buf, 0, n);
                    }
                }
                zis.closeEntry();
            }
        }

        // زیپ یک پوشه‌ی ریشه دارد؛ محتویاتش را بالا می‌آوریم
        File root = tmp;
        File[] kids = tmp.listFiles();
        if (kids != null && kids.length == 1 && kids[0].isDirectory()) root = kids[0];

        deleteTree(dest);
        if (!root.renameTo(dest)) {
            copyTree(root, dest);
            deleteTree(tmp);
        }
    }

    private void copyTree(File from, File to) throws Exception {
        if (from.isDirectory()) {
            to.mkdirs();
            File[] kids = from.listFiles();
            if (kids != null) for (File k : kids) copyTree(k, new File(to, k.getName()));
        } else {
            try (InputStream in = new java.io.FileInputStream(from);
                 FileOutputStream out = new FileOutputStream(to)) {
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
            }
        }
    }

    private void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }
}
