package app.niko.assistant;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;

/**
 * گوش بیدارباش: کاملاً آفلاین با Vosk.
 * فقط منتظر شنیدن «نیکو» می‌ماند.
 */
public class WakeWord {

    private static final String TAG = "NikoWake";

    public interface Listener {
        void onWake();
    }

    private volatile boolean running = false;
    private Thread thread;
    private volatile AudioRecord liveRec;
    private Model model;
    private final Context ctx;

    public WakeWord(Context c) {
        this.ctx = c.getApplicationContext();
    }

    public static File modelDir(Context c) {
        return new File(c.getFilesDir(), "vosk-fa");
    }

    public static boolean modelReady(Context c) {
        File d = modelDir(c);
        return d.isDirectory() && new File(d, "am").isDirectory();
    }

    public boolean loadModel() {
        if (model != null) return true;
        try {
            model = new Model(modelDir(ctx).getAbsolutePath());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "model load failed", e);
            return false;
        }
    }

    @SuppressLint("MissingPermission")
    public void start(final Listener listener) {
        if (running) return;
        if (!loadModel()) {
            Log.e(TAG, "no model");
            return;
        }
        running = true;

        thread = new Thread(() -> {
            int rate = 16000;
            int minBuf = AudioRecord.getMinBufferSize(rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bufSize = Math.max(minBuf * 2, 8000);

            AudioRecord rec = null;
            Recognizer rec2 = null;
            try {
                rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        rate, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, bufSize * 2);
                if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                    running = false;
                    return;
                }
                liveRec = rec;

                // گرامر محدود = دقت بالا و مصرف کم
                String grammar = "[\"نیکو\", \"هی نیکو\", \"نیکو جان\", \"[unk]\"]";
                try {
                    rec2 = new Recognizer(model, (float) rate, grammar);
                } catch (Exception e) {
                    Log.w(TAG, "grammar rejected, falling back", e);
                    rec2 = new Recognizer(model, (float) rate);
                }

                rec.startRecording();
                short[] buf = new short[bufSize];

                while (running) {
                    int n = rec.read(buf, 0, buf.length);
                    if (n <= 0) continue;

                    if (rec2.acceptWaveForm(buf, n)) {
                        String res = rec2.getResult();
                        if (hit(res)) {
                            listener.onWake();
                        }
                    } else {
                        String part = rec2.getPartialResult();
                        if (hit(part)) {
                            listener.onWake();
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "wake loop died", e);
            } finally {
                running = false;
                liveRec = null;
                try {
                    if (rec2 != null) rec2.close();
                } catch (Exception ignored) {
                }
                try {
                    if (rec != null) {
                        if (rec.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) rec.stop();
                        rec.release();
                    }
                } catch (Exception ignored) {
                }
            }
        }, "niko-wake");
        thread.start();
    }

    private boolean hit(String json) {
        if (json == null) return false;
        try {
            String t = new JSONObject(json).optString("text", "")
                    + new JSONObject(json).optString("partial", "");
            t = t.replace("ي", "ی").replace("ك", "ک").replace("‌", "");
            return t.contains("نیکو");
        } catch (Exception e) {
            return false;
        }
    }

    public void stop() {
        running = false;
        // خواندنِ AudioRecord مسدود است؛ با stop آزادش می‌کنیم تا میکروفون زودتر آزاد شود
        try {
            AudioRecord r = liveRec;
            if (r != null && r.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) r.stop();
        } catch (Exception ignored) {
        }
        try {
            if (thread != null) thread.join(1500);
        } catch (InterruptedException ignored) {
        }
        thread = null;
    }

    public boolean isRunning() {
        return running;
    }

    public void release() {
        stop();
        try {
            if (model != null) model.close();
        } catch (Exception ignored) {
        }
        model = null;
    }
}
