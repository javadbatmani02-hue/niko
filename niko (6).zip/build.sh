#!/bin/bash
set -e

echo "=== WORKSPACE ==="
pwd
ls -la

rm -rf /tmp/b
mkdir -p /tmp/b/java /tmp/b/main /tmp/b/res/layout /tmp/b/res/values /tmp/b/res/drawable

find /tmp/x -name '*.java' -exec cp {} /tmp/b/java/ \;
find /tmp/x -name 'AndroidManifest.xml' -exec cp {} /tmp/b/main/ \;
find /tmp/x -name 'activity_main.xml' -exec cp {} /tmp/b/res/layout/ \;
find /tmp/x -name 'strings.xml' -exec cp {} /tmp/b/res/values/ \;
find /tmp/x -name 'styles.xml' -exec cp {} /tmp/b/res/values/ \;
find /tmp/x -name 'ic_launcher*' -exec cp {} /tmp/b/res/drawable/ \;

echo "=== FOUND ==="
ls /tmp/b/java
ls /tmp/b/main
ls /tmp/b/res/layout /tmp/b/res/values /tmp/b/res/drawable

rm -rf app
mkdir -p app/src/main/java/app/niko/assistant
mkdir -p app/src/main/res/layout app/src/main/res/values app/src/main/res/drawable

cp /tmp/b/java/*.java app/src/main/java/app/niko/assistant/
cp /tmp/b/main/AndroidManifest.xml app/src/main/
cp /tmp/b/res/layout/activity_main.xml app/src/main/res/layout/
cp /tmp/b/res/values/strings.xml app/src/main/res/values/
cp /tmp/b/res/values/styles.xml app/src/main/res/values/
cp /tmp/b/res/drawable/* app/src/main/res/drawable/ 2>/dev/null || true

cat > settings.gradle <<'EOF'
rootProject.name = "Niko"
include ':app'
EOF

cat > gradle.properties <<'EOF'
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=false
android.nonTransitiveRClass=false
EOF

cat > build.gradle <<'EOF'
buildscript {
    repositories { google(); mavenCentral() }
    dependencies { classpath 'com.android.tools.build:gradle:8.1.2' }
}
allprojects {
    repositories { google(); mavenCentral() }
}
EOF

cat > app/build.gradle <<'EOF'
apply plugin: 'com.android.application'

android {
    namespace 'app.niko.assistant'
    compileSdk 33
    defaultConfig {
        applicationId "app.niko.assistant"
        minSdk 24
        targetSdk 33
        versionCode 1
        versionName "1.0"
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    lint {
        abortOnError false
        checkReleaseBuilds false
    }
}

dependencies {
    implementation 'com.alphacephei:vosk-android:0.3.47'
    implementation 'net.java.dev.jna:jna:5.13.0@aar'
}
EOF

echo "=== PROJECT TREE ==="
find app -type f | sort
echo "=== PREPARE OK ==="
